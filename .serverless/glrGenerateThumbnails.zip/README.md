# glrGenerateThumbnails
Generate Thumbnails lambda serverless
